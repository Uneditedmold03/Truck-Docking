
public class Van extends Vehicle {

    public Van(int weight) {
        setVehicleType("Van");
        setVehicleWeight(weight);
    }

    // parameter = ( )
    // Metod(parameter)

    @Override
    public String getVehicleType() {
        return super.getVehicleType();
    }

    @Override
    public int getVehicleWeight() {
        return super.getVehicleWeight();
    }

}
