
public class LightTruck extends Vehicle {

    public LightTruck(int weight) {
        setVehicleType("Truck");
        setVehicleWeight(weight);

    }

    @Override
    public String getVehicleType() {
        return super.getVehicleType();
    }

    @Override
    public int getVehicleWeight() {
        return super.getVehicleWeight();
    }
}
