
public class Heavytruck extends Vehicle {

    public Heavytruck(int weight) {
        setVehicleType("Heavy Truck");
        setVehicleWeight(weight);
    }

    @Override
    public String getVehicleType() {
        return super.getVehicleType();
    }


}
